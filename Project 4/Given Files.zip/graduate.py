# Project 4 – Graduate Rate (2017-2018)
# Name:
# Instructor: Dr. S. Einakian
# Section:
# main program
from graduate_funcs import *