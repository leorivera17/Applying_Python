# Project 4 – Graduate Rate (2017-2018)
# Name:
# Instructor: Dr. S. Einakian
# Section:
# classes and functionalities will be provided here

# class Division


# class Graduate:


# read file and return list of strings


# create list of Division objects


# create list of Graduate objects


# create files for each division


# find total and average graduate for all divisions


# find (female, male) graduate rate for given major

