# Project 4 – Graduate Rate (2017-2018)
# Name:
# Instructor: Dr. S. Einakian
# Section:

# unittest cases for graduate rate will include here
import unittest
from graduate_funcs import *
class TestCases(unittest.TestCase):



# Run the unit tests.
if __name__ == '__main__':
    unittest.main()
