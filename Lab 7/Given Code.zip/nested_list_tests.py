#unittest for objects
import unittest
from nested_list import *

class TestCases(unittest.TestCase):
   def test_groups_of_3(self):
      # Add code here.
      pass




# Run the unit tests.
if __name__ == '__main__':
   unittest.main()